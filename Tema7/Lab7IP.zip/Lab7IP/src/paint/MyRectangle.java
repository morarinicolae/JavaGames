package paint;

import java.awt.Color;
import java.awt.Point;
import java.awt.Rectangle;
import java.io.BufferedWriter;

public class MyRectangle implements Class2D{
	private Rectangle rect;
	
	public MyRectangle() {
		
	}
	public MyRectangle(Rectangle r) {
		this.rect = r;
	}
	
	public void makeObject(Point startDrag, Point endDrag) {
		Rectangle r = new Rectangle(Math.min(startDrag.x, endDrag.x), Math.min(startDrag.y, endDrag.y), Math.abs(startDrag.x - endDrag.x), Math.abs(startDrag.y - endDrag.y));	
		this.setRect(r);
	}
	
	public void makeRectangle(int x, int y, int w, int h) {
		Rectangle r = new Rectangle(x, y, w, h);
	    this.setRect(r);
	}
	
    @Override
	public void draw(GraphicAdapter g) {	
   		g.getGraphicAdapter().drawRect(this.getRect().x, this.getRect().y, this.getRect().width, this.getRect().height);
    }
    @Override
    public void fill(Color c){
		
	}
    @Override
    public boolean contains(Point p) {
    	return this.getRect().contains(p);
    }
   
    @Override
    public void move(Point startDrag, Point endDrag){
    }

    public void writetoFile(BufferedWriter b){	
    }
    
	public Rectangle getRect() {
		return rect;
	}
	public void setRect(Rectangle rect) {
		this.rect = rect;
	}
	
}
