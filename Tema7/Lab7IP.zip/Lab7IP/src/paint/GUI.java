package paint;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

@SuppressWarnings("serial")
public class GUI extends JFrame {

	public static String selectShap = "";
	public static ArrayList<Paint> paint = new ArrayList<Paint>();
	private JPanel contentPane;
	public static GUI frame;  
	
	public static void main(String[] args) 
    {
    	try{
    		frame = new GUI();
    		frame.setVisible(true);
    		frame.setLocationRelativeTo(null);
    		frame.setResizable(false);
    	}catch (Exception e) {
			e.printStackTrace();
		}
    }
	
	public GUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Editor Grafic");
		setSize(500, 500);
		setMinimumSize(getSize());
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		contentPane.setBackground(Color.white);
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		FlowLayout flowLayout = (FlowLayout) panel.getLayout();
		flowLayout.setAlignment(FlowLayout.LEFT);
		panel.setBackground(Color.darkGray);
		contentPane.add(panel, BorderLayout.NORTH);
		

		JButton btnSquare = new JButton("Square");
		btnSquare.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				selectShap = "Square";
			}
		});
		panel.add(btnSquare);
		

		JButton btnCir = new JButton("Circle");
		btnCir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				selectShap = "Circle";
			}
		});
		panel.add(btnCir);
		

		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				selectShap = "Delete";
			}
		});
		panel.add(btnDelete);
			
		contentPane.add(new Paint_App(), BorderLayout.CENTER);
		validate();
	}
}
