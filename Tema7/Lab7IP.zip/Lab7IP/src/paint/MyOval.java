package paint;

import java.awt.Color;
import java.awt.Point;
import java.awt.geom.Ellipse2D;
import java.io.BufferedWriter;


public class MyOval implements Class2D{
	private Ellipse2D elip2d;
	
	public MyOval() {
	}
	
	public MyOval(Ellipse2D e) {
		this.elip2d = e;
	}
	
	@Override
	public void makeObject(Point startDrag, Point endDrag) {
		Ellipse2D r = new Ellipse2D.Float(Math.min(startDrag.x, endDrag.x), Math.min(startDrag.y, endDrag.y), Math.abs(startDrag.x - endDrag.x), Math.abs(startDrag.y - endDrag.y));
	    this.setElip2d(r);
	}
	
	public void makeOval(int x, int y, int w, int h) {
		Ellipse2D r = new Ellipse2D.Float(x, y, w, h);
		this.setElip2d(r);
	}
	
	
	@Override
    public void draw(GraphicAdapter g) {
    	g.getGraphicAdapter().drawOval((int)getElip2d().getX(),(int)getElip2d().getY(), (int)getElip2d().getWidth(), (int)getElip2d().getHeight());
    	
    }
	@Override
	public void fill(Color c){
	}
	
    @Override
    public boolean contains(Point p) {
    	return this.getElip2d().contains(p);
    }
    @Override
    public void move(Point startDrag, Point endDrag){
    	
    }
    
    @Override
    public void writetoFile(BufferedWriter b){
    }
    
	public Ellipse2D getElip2d() {
		return elip2d;
	}
	public void setElip2d(Ellipse2D elip2d) {
		this.elip2d = elip2d;
	}
	
	
    
}
