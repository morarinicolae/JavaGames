package paint;

import java.awt.Color;

public interface Class2D extends Paint{
	   public void fill(Color color);	
	}