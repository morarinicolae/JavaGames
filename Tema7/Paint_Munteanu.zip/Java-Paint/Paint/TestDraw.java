
public class TestDraw
{
    public static void main( String args[] )
    {
        DrawFrame paintGui = new DrawFrame(); //initalize DrawFrame object called paintGui     
    } // end main
} // end class TestDraw